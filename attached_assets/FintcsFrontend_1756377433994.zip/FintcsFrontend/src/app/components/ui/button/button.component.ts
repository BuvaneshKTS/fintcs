import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {
  @Input() type: string = 'button';
  @Input() variant: 'primary' | 'secondary' | 'outline' | 'danger' = 'primary';
  @Input() size: 'sm' | 'md' | 'lg' = 'md';
  @Input() disabled: boolean = false;
  @Input() loading: boolean = false;
  @Input() icon: string = '';
  @Input() fullWidth: boolean = false;
  
  @Output() clicked = new EventEmitter<void>();

  onClick(): void {
    if (!this.disabled && !this.loading) {
      this.clicked.emit();
    }
  }

  get buttonClasses(): string {
    const classes = ['btn'];
    
    if (this.variant === 'primary') classes.push('btn-primary');
    if (this.variant === 'secondary') classes.push('btn-secondary');
    if (this.variant === 'outline') classes.push('btn-outline');
    if (this.variant === 'danger') classes.push('btn-danger');
    
    if (this.size === 'sm') classes.push('h-8', 'px-3', 'text-xs');
    if (this.size === 'md') classes.push('h-10', 'px-4', 'text-sm');
    if (this.size === 'lg') classes.push('h-12', 'px-6', 'text-base');
    
    if (this.fullWidth) classes.push('w-full');
    
    return classes.join(' ');
  }
}