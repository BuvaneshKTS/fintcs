import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth.service';

interface MenuItem {
  icon: string;
  label: string;
  path: string;
  roles: string[];
}

interface MenuSection {
  title: string;
  items: MenuItem[];
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: MenuSection[] = [
    {
      title: 'DASHBOARD',
      items: [
        {
          icon: 'fas fa-chart-pie',
          label: 'Overview',
          path: '/dashboard',
          roles: ['user', 'admin']
        }
      ]
    },
    {
      title: 'FILE MANAGEMENT',
      items: [
        {
          icon: 'fas fa-building',
          label: 'Society',
          path: '/admin/society',
          roles: ['admin']
        },
        {
          icon: 'fas fa-users',
          label: 'Members',
          path: '/members',
          roles: ['user', 'admin']
        }
      ]
    },
    {
      title: 'SECURITY',
      items: [
        {
          icon: 'fas fa-user-plus',
          label: 'New User',
          path: '/admin/users',
          roles: ['admin']
        },
        {
          icon: 'fas fa-shield-alt',
          label: 'Authority',
          path: '#',
          roles: ['admin']
        },
        {
          icon: 'fas fa-key',
          label: 'My Rights',
          path: '#',
          roles: ['user', 'admin']
        },
        {
          icon: 'fas fa-lock',
          label: 'Change Password',
          path: '#',
          roles: ['user', 'admin']
        }
      ]
    }
  ];

  constructor(private authService: AuthService) {}

  ngOnInit(): void {}

  canAccess(item: MenuItem): boolean {
    return item.roles.some(role => this.authService.hasRole(role));
  }

  getMembersPath(): string {
    return this.authService.isAdmin() ? '/admin/members' : '/members';
  }
}