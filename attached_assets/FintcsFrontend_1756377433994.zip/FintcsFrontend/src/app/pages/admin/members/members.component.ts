import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { Member, MemberCreateRequest, ApiResponse } from '../../../models/api.model';

@Component({
  selector: 'app-admin-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class AdminMembersComponent implements OnInit {
  members: Member[] = [];
  loading = true;
  saving = false;
  deleting = false;
  error = '';
  isCreateModalOpen = false;
  isEditModalOpen = false;
  selectedMember: Member | null = null;
  memberForm: FormGroup;

  constructor(
    private apiService: ApiService,
    private fb: FormBuilder
  ) {
    this.memberForm = this.createForm();
  }

  ngOnInit(): void {
    this.fetchMembers();
  }

  createForm(): FormGroup {
    return this.fb.group({
      name: ['', Validators.required],
      fhName: [''],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', Validators.required],
      phoneOffice: [''],
      phoneRes: [''],
      officeAddress: [''],
      residenceAddress: [''],
      city: [''],
      branch: [''],
      designation: [''],
      dob: ['', Validators.required],
      dojSociety: ['', Validators.required],
      dojOrg: [''],
      nominee: [''],
      nomineeRelation: [''],
      bankingDetails: this.fb.group({
        BankName: [''],
        AccountNumber: [''],
        IFSCCode: [''],
        BranchName: [''],
        AccountHolderName: ['']
      })
    });
  }

  fetchMembers(): void {
    this.loading = true;
    this.apiService.get<ApiResponse<Member[]>>('/members').subscribe({
      next: (response) => {
        if (response.success && response.data) {
          this.members = response.data;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to fetch members';
        this.loading = false;
      }
    });
  }

  openCreateModal(): void {
    this.memberForm.reset();
    this.isCreateModalOpen = true;
    this.error = '';
  }

  closeCreateModal(): void {
    this.isCreateModalOpen = false;
    this.error = '';
  }

  openEditModal(member: Member): void {
    this.selectedMember = member;
    this.populateForm(member);
    this.isEditModalOpen = true;
    this.error = '';
  }

  closeEditModal(): void {
    this.isEditModalOpen = false;
    this.selectedMember = null;
    this.error = '';
  }

  populateForm(member: Member): void {
    this.memberForm.patchValue({
      name: member.name,
      fhName: member.fhName,
      email: member.email,
      mobile: member.mobile,
      phoneOffice: member.phoneOffice,
      phoneRes: member.phoneRes,
      officeAddress: member.officeAddress,
      residenceAddress: member.residenceAddress,
      city: member.city,
      branch: member.branch,
      designation: member.designation,
      dob: member.dob?.split('T')[0],
      dojSociety: member.dojSociety?.split('T')[0],
      dojOrg: member.dojOrg?.split('T')[0],
      nominee: member.nominee,
      nomineeRelation: member.nomineeRelation,
      bankingDetails: member.bankingDetails
    });
  }

  onCreateMember(): void {
    if (this.memberForm.valid) {
      this.saving = true;
      this.error = '';

      this.apiService.post<ApiResponse<Member>>('/members', this.memberForm.value).subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.members.push(response.data);
            this.closeCreateModal();
          }
          this.saving = false;
        },
        error: (error) => {
          this.error = error.error?.message || 'Failed to create member';
          this.saving = false;
        }
      });
    }
  }

  onUpdateMember(): void {
    if (this.memberForm.valid && this.selectedMember) {
      this.saving = true;
      this.error = '';

      this.apiService.put<ApiResponse<Member>>(`/members/${this.selectedMember.id}`, this.memberForm.value).subscribe({
        next: (response) => {
          if (response.success && response.data) {
            const index = this.members.findIndex(m => m.id === this.selectedMember!.id);
            if (index !== -1) {
              this.members[index] = response.data;
            }
            this.closeEditModal();
          }
          this.saving = false;
        },
        error: (error) => {
          this.error = error.error?.message || 'Failed to update member';
          this.saving = false;
        }
      });
    }
  }

  deleteMember(member: Member): void {
    if (confirm(`Are you sure you want to delete ${member.name}?`)) {
      this.deleting = true;
      
      this.apiService.delete<ApiResponse<void>>(`/members/${member.id}`).subscribe({
        next: (response) => {
          if (response.success) {
            this.members = this.members.filter(m => m.id !== member.id);
          }
          this.deleting = false;
        },
        error: (error) => {
          this.error = 'Failed to delete member';
          this.deleting = false;
        }
      });
    }
  }
}