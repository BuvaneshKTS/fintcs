import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { Society, ApiResponse } from '../../../models/api.model';

@Component({
  selector: 'app-admin-society',
  templateUrl: './society.component.html',
  styleUrls: ['./society.component.css']
})
export class AdminSocietyComponent implements OnInit {
  society: Society | null = null;
  loading = true;
  saving = false;
  error = '';
  isEditModalOpen = false;
  societyForm: FormGroup;

  constructor(
    private apiService: ApiService,
    private fb: FormBuilder
  ) {
    this.societyForm = this.createForm();
  }

  ngOnInit(): void {
    this.fetchSociety();
  }

  createForm(): FormGroup {
    return this.fb.group({
      societyName: ['', Validators.required],
      address: [''],
      city: [''],
      phone: [''],
      fax: [''],
      email: ['', Validators.email],
      website: [''],
      registrationNumber: [''],
      interestRates: this.fb.group({
        Dividend: [0, [Validators.min(0), Validators.max(100)]],
        OD: [0, [Validators.min(0), Validators.max(100)]],
        CD: [0, [Validators.min(0), Validators.max(100)]],
        Loan: [0, [Validators.min(0), Validators.max(100)]],
        EmergencyLoan: [0, [Validators.min(0), Validators.max(100)]],
        LAS: [0, [Validators.min(0), Validators.max(100)]]
      }),
      limits: this.fb.group({
        Share: [0, [Validators.min(0)]],
        Loan: [0, [Validators.min(0)]],
        EmergencyLoan: [0, [Validators.min(0)]]
      })
    });
  }

  fetchSociety(): void {
    this.loading = true;
    this.apiService.get<ApiResponse<Society>>('/society').subscribe({
      next: (response) => {
        if (response.success && response.data) {
          this.society = response.data;
          this.populateForm(response.data);
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to fetch society data';
        this.loading = false;
      }
    });
  }

  populateForm(society: Society): void {
    this.societyForm.patchValue({
      societyName: society.societyName,
      address: society.address,
      city: society.city,
      phone: society.phone,
      fax: society.fax,
      email: society.email,
      website: society.website,
      registrationNumber: society.registrationNumber,
      interestRates: society.tabs.Interest,
      limits: society.tabs.Limit
    });
  }

  openEditModal(): void {
    if (this.society) {
      this.populateForm(this.society);
    }
    this.isEditModalOpen = true;
  }

  closeEditModal(): void {
    this.isEditModalOpen = false;
    this.error = '';
  }

  onSave(): void {
    if (this.societyForm.valid) {
      this.saving = true;
      this.error = '';

      const formValue = this.societyForm.value;
      const societyData = {
        ...formValue,
        tabs: {
          Interest: formValue.interestRates,
          Limit: formValue.limits
        }
      };

      this.apiService.put<ApiResponse<Society>>('/society', societyData).subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.society = response.data;
            this.closeEditModal();
          }
          this.saving = false;
        },
        error: (error) => {
          this.error = 'Failed to update society';
          this.saving = false;
        }
      });
    }
  }
}