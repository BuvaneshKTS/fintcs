import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { User, RegisterRequest, ApiResponse } from '../../../models/api.model';

@Component({
  selector: 'app-admin-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class AdminUsersComponent implements OnInit {
  users: User[] = [];
  loading = true;
  saving = false;
  error = '';
  isCreateModalOpen = false;
  userForm: FormGroup;

  constructor(
    private apiService: ApiService,
    private fb: FormBuilder
  ) {
    this.userForm = this.createForm();
  }

  ngOnInit(): void {
    this.fetchUsers();
  }

  createForm(): FormGroup {
    return this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      EDPNo: [''],
      Name: [''],
      AddressOffice: [''],
      AddressResidential: [''],
      Designation: [''],
      PhoneOffice: [''],
      PhoneResidential: [''],
      Mobile: ['']
    });
  }

  fetchUsers(): void {
    this.loading = true;
    this.apiService.get<ApiResponse<User[]>>('/users').subscribe({
      next: (response) => {
        if (response.success && response.data) {
          this.users = response.data;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to fetch users';
        this.loading = false;
      }
    });
  }

  openCreateModal(): void {
    this.userForm.reset();
    this.isCreateModalOpen = true;
    this.error = '';
  }

  closeCreateModal(): void {
    this.isCreateModalOpen = false;
    this.error = '';
  }

  onCreateUser(): void {
    if (this.userForm.valid) {
      this.saving = true;
      this.error = '';

      this.apiService.post<ApiResponse<User>>('/auth/register', this.userForm.value).subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.users.push(response.data);
            this.closeCreateModal();
          }
          this.saving = false;
        },
        error: (error) => {
          this.error = error.error?.message || 'Failed to create user';
          this.saving = false;
        }
      });
    }
  }

  updateUserRole(userId: number, newRole: string): void {
    this.apiService.put<ApiResponse<User>>(`/users/${userId}/role`, [newRole]).subscribe({
      next: (response) => {
        if (response.success && response.data) {
          const userIndex = this.users.findIndex(u => u.id === userId);
          if (userIndex !== -1) {
            this.users[userIndex] = response.data;
          }
        }
      },
      error: (error) => {
        this.error = 'Failed to update user role';
      }
    });
  }

  isAdmin(user: User): boolean {
    return user.roles.includes('admin');
  }
}