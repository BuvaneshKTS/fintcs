import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { LoginResponse } from '../../models/api.model';

interface StatCard {
  title: string;
  value: string;
  change: string;
  changePositive: boolean;
  icon: string;
  color: string;
  description: string;
}

interface QuickAction {
  label: string;
  icon: string;
  color: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentUser: LoginResponse | null = null;
  
  stats: StatCard[] = [
    {
      title: 'Total Members',
      value: '1,234',
      change: '+12% this month',
      changePositive: true,
      icon: 'fas fa-users',
      color: 'bg-blue-500',
      description: 'Active members in system'
    },
    {
      title: 'Total Deposits',
      value: '₹45.2M',
      change: '+8.5% this month',
      changePositive: true,
      icon: 'fas fa-university',
      color: 'bg-green-500',
      description: 'Total deposits amount'
    },
    {
      title: 'Active Loans',
      value: '156',
      change: '+2.3% this month',
      changePositive: true,
      icon: 'fas fa-coins',
      color: 'bg-orange-500',
      description: 'Currently active loans'
    },
    {
      title: 'Interest Earned',
      value: '₹2.1M',
      change: '+15.2% this month',
      changePositive: true,
      icon: 'fas fa-chart-line',
      color: 'bg-purple-500',
      description: 'Total interest earned'
    }
  ];

  quickActions: QuickAction[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.setupQuickActions();
    });
  }

  setupQuickActions(): void {
    if (this.authService.isAdmin()) {
      this.quickActions = [
        { label: 'New Member', icon: 'fas fa-user-plus', color: 'bg-purple-600' },
        { label: 'New Deposit', icon: 'fas fa-plus-circle', color: 'bg-blue-600' },
        { label: 'Process Loan', icon: 'fas fa-file-invoice-dollar', color: 'bg-green-600' }
      ];
    } else {
      this.quickActions = [
        { label: 'View Members', icon: 'fas fa-users', color: 'bg-purple-600' },
        { label: 'My Profile', icon: 'fas fa-user', color: 'bg-blue-600' }
      ];
    }
  }
}