import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Member, ApiResponse } from '../../../models/api.model';

@Component({
  selector: 'app-user-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class UserMembersComponent implements OnInit {
  members: Member[] = [];
  loading = true;
  error = '';
  searchTerm = '';

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.fetchMembers();
  }

  fetchMembers(): void {
    this.loading = true;
    this.apiService.get<ApiResponse<Member[]>>('/members').subscribe({
      next: (response) => {
        if (response.success && response.data) {
          this.members = response.data;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to fetch members';
        this.loading = false;
      }
    });
  }

  get filteredMembers(): Member[] {
    if (!this.searchTerm) return this.members;
    
    return this.members.filter(member =>
      member.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      member.email.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      member.memNo.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}