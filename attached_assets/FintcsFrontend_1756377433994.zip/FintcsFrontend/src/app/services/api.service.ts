import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly API_BASE_URL = 'http://localhost:5000/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getHttpOptions(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : ''
      })
    };
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 401) {
      this.authService.logout();
      window.location.href = '/login';
    }
    return throwError(() => error);
  }

  get<T>(url: string): Observable<T> {
    return this.http.get<T>(`${this.API_BASE_URL}${url}`, this.getHttpOptions())
      .pipe(catchError(this.handleError.bind(this)));
  }

  post<T>(url: string, data?: any): Observable<T> {
    return this.http.post<T>(`${this.API_BASE_URL}${url}`, data, this.getHttpOptions())
      .pipe(catchError(this.handleError.bind(this)));
  }

  put<T>(url: string, data?: any): Observable<T> {
    return this.http.put<T>(`${this.API_BASE_URL}${url}`, data, this.getHttpOptions())
      .pipe(catchError(this.handleError.bind(this)));
  }

  delete<T>(url: string): Observable<T> {
    return this.http.delete<T>(`${this.API_BASE_URL}${url}`, this.getHttpOptions())
      .pipe(catchError(this.handleError.bind(this)));
  }
}