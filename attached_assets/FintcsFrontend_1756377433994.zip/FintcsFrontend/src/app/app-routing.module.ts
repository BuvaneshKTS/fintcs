import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/auth/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LayoutComponent } from './components/layout/layout/layout.component';
import { AdminSocietyComponent } from './pages/admin/society/society.component';
import { AdminUsersComponent } from './pages/admin/users/users.component';
import { AdminMembersComponent } from './pages/admin/members/members.component';
import { UserMembersComponent } from './pages/user/members/members.component';
import { AuthGuard } from './guards/auth.guard';
import { AdminGuard } from './guards/admin.guard';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { 
    path: '', 
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'admin/society', component: AdminSocietyComponent, canActivate: [AdminGuard] },
      { path: 'admin/users', component: AdminUsersComponent, canActivate: [AdminGuard] },
      { path: 'admin/members', component: AdminMembersComponent, canActivate: [AdminGuard] },
      { path: 'members', component: UserMembersComponent }
    ]
  },
  { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }