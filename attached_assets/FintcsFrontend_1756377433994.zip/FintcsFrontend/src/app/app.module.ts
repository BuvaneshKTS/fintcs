import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/auth/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LayoutComponent } from './components/layout/layout/layout.component';
import { HeaderComponent } from './components/layout/header/header.component';
import { SidebarComponent } from './components/layout/sidebar/sidebar.component';
import { AdminSocietyComponent } from './pages/admin/society/society.component';
import { AdminUsersComponent } from './pages/admin/users/users.component';
import { AdminMembersComponent } from './pages/admin/members/members.component';
import { UserMembersComponent } from './pages/user/members/members.component';

// UI Components
import { ButtonComponent } from './components/ui/button/button.component';
import { InputComponent } from './components/ui/input/input.component';
import { CardComponent } from './components/ui/card/card.component';
import { ModalComponent } from './components/ui/modal/modal.component';
import { LoadingSpinnerComponent } from './components/ui/loading-spinner/loading-spinner.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    LayoutComponent,
    HeaderComponent,
    SidebarComponent,
    AdminSocietyComponent,
    AdminUsersComponent,
    AdminMembersComponent,
    UserMembersComponent,
    ButtonComponent,
    InputComponent,
    CardComponent,
    ModalComponent,
    LoadingSpinnerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }