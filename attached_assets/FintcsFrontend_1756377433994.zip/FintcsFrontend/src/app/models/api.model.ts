// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T | null;
  errors: string[];
}

// User Types
export interface User {
  id: number;
  username: string;
  email: string;
  phone: string;
  roles: string;
  details: UserDetails;
  createdAt: string;
}

export interface UserDetails {
  EDPNo: string;
  Name: string;
  AddressOffice: string;
  AddressResidential: string;
  Designation: string;
  PhoneOffice: string;
  PhoneResidential: string;
  Mobile: string;
  Email: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email: string;
  phone?: string;
  EDPNo?: string;
  Name?: string;
  AddressOffice?: string;
  AddressResidential?: string;
  Designation?: string;
  PhoneOffice?: string;
  PhoneResidential?: string;
  Mobile?: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  email: string;
  phone: string;
  roles: string;
  details: UserDetails;
  expiresAt: string;
}

// Society Types
export interface Society {
  id: number;
  societyName: string;
  address: string;
  city: string;
  phone: string;
  fax: string;
  email: string;
  website: string;
  registrationNumber: string;
  tabs: SocietyTabs;
  isPendingApproval: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SocietyTabs {
  Interest: InterestRates;
  Limit: Limits;
}

export interface InterestRates {
  Dividend: number;
  OD: number;
  CD: number;
  Loan: number;
  EmergencyLoan: number;
  LAS: number;
}

export interface Limits {
  Share: number;
  Loan: number;
  EmergencyLoan: number;
}

// Member Types
export interface Member {
  id: number;
  memNo: string;
  name: string;
  fhName: string;
  officeAddress: string;
  city: string;
  phoneOffice: string;
  branch: string;
  phoneRes: string;
  mobile: string;
  designation: string;
  residenceAddress: string;
  dob: string;
  dojSociety: string;
  email: string;
  dojOrg: string;
  dor?: string;
  nominee: string;
  nomineeRelation: string;
  bankingDetails: BankingDetails;
  isPendingApproval: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface BankingDetails {
  BankName: string;
  AccountNumber: string;
  IFSCCode: string;
  BranchName: string;
  AccountHolderName: string;
}

export interface MemberCreateRequest {
  name: string;
  fhName: string;
  officeAddress: string;
  city: string;
  phoneOffice: string;
  branch: string;
  phoneRes: string;
  mobile: string;
  designation: string;
  residenceAddress: string;
  dob: string;
  dojSociety: string;
  email: string;
  dojOrg: string;
  dor?: string;
  nominee: string;
  nomineeRelation: string;
  bankingDetails: BankingDetails;
}

// Dashboard Types
export interface DashboardStats {
  totalMembers: number;
  totalDeposits: number;
  activeLoans: number;
  interestEarned: number;
}