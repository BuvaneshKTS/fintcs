# FinTCS - Financial Management System

## Overview

FinTCS is a comprehensive financial management system designed for cooperative societies. The application provides member management, user administration, and financial tracking capabilities with role-based access control. Built as a full-stack web application, it features a modern React frontend with TypeScript and a Node.js/Express backend, utilizing PostgreSQL with Drizzle ORM for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 19 with TypeScript for type safety and modern component patterns
- **Routing**: React Router DOM for client-side navigation with protected routes
- **Styling**: Tailwind CSS with custom design system including purple/blue color scheme
- **State Management**: React Context API for authentication state, with local component state for UI interactions
- **Build Tool**: Vite for fast development and optimized production builds
- **Icons**: Font Awesome for consistent iconography throughout the application

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for API development
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: JWT-based authentication with role-based access control (user/admin roles)
- **Session Management**: Express sessions with PostgreSQL session storage using connect-pg-simple
- **API Design**: RESTful API structure with consistent response formatting

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless database for scalability
- **ORM**: Drizzle ORM with schema-first approach for type safety
- **Session Storage**: PostgreSQL-based session storage for authentication persistence
- **Connection Pooling**: Neon serverless connection pooling for optimal database performance

### Authentication and Authorization
- **Strategy**: JWT tokens for stateless authentication
- **Role System**: Two-tier role system (user/admin) with granular permission controls
- **Protected Routes**: Frontend route protection based on authentication status and user roles
- **Session Persistence**: Local storage for token persistence with automatic logout on token expiry

### Component Architecture
- **Design System**: Custom UI component library built on Tailwind CSS
- **Layout Structure**: Nested layout with sidebar navigation and protected route wrappers
- **Form Handling**: Controlled components with validation and error handling
- **Modal System**: Reusable modal components for create/edit operations
- **Loading States**: Comprehensive loading and error state management throughout the application

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver for database connectivity
- **drizzle-orm** and **drizzle-kit**: Type-safe ORM and migration toolkit for PostgreSQL
- **express** and **express-session**: Web server framework with session management
- **react** and **react-dom**: Frontend framework for building user interfaces
- **react-router-dom**: Client-side routing solution for single-page application navigation

### Authentication & Security
- **passport**: Authentication middleware for flexible login strategies
- **openid-client**: OpenID Connect client implementation for potential SSO integration
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Development Tools
- **typescript**: Static type checking for enhanced code quality
- **vite**: Modern build tool with hot module replacement for development
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **@vitejs/plugin-react**: Vite plugin for React support with fast refresh

### Utility Libraries
- **axios**: HTTP client for API communications with interceptors for authentication
- **@tanstack/react-query**: Server state management and data fetching (prepared for future use)
- **ws**: WebSocket implementation for potential real-time features
- **memoizee**: Function memoization for performance optimization

### API Integration
- **External Backend**: The system is designed to integrate with a separate ASP.NET Core API (FintcsApi) running on localhost:5000
- **API Structure**: RESTful endpoints for user management, member management, and society configuration
- **Authentication Flow**: JWT token-based authentication with automatic token refresh and logout handling